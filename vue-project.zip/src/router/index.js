import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import DataBinding from '@/components/DataBinding'
import DataMethod from '@/components/DataMethod'
import Event from '@/components/Event'
import EventModifier from '@/components/EventModifier'
import HelloWorld from '@/components/HelloWorld'
import KeyboardEvents from '@/components/KeyboardEvents'
import NotFound from '@/components/NotFound'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {path: '/', name: 'Home', component: Home},
    {path: "*", name: 'NotFound', component: NotFound },
    {path: '/binding', name: 'DataBinding', component: DataBinding},
    {path: '/home', name: 'DataBinding', component: DataBinding},
    {path: '/datamethod', name: 'DataMethod', component: DataMethod},
    {path: '/event', name: 'Event', component: Event},
    {path: '/event-modifier', name: 'EventModifier', component: EventModifier},
    {path: '/hello', name: 'HelloWorld', component: HelloWorld},
    {path: '/keyboard', name: 'KeyboardEvents', component: KeyboardEvents},
    {path: '/two-way-binding', name: 'DataBinding', component: DataBinding},
  ]
})

<template>
  <div>
    <h1>{{greet()}}</h1>
    <h2>Name: {{ name }}</h2>
    <p>Job: {{ job }}</p>
    <p>Age: {{ age }}</p>
  </div>
</template>

<script>
export default {
  name: 'DataMethod',
  data () {
    return {
      name: 'Kai',
      job: 'DEV',
      age: 23
    }
  },
  methods: {
    greet(name){
      if(name == null || name.length === 0) return 'Hello ' + this.name + '!!!'; 
      else return 'Hello ' + name + '!!!';
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>

<template>
  <div>
    <h1>{{msg}}</h1>
    <div class="group-data">
      <div class="group-data-item">
        <label>Name: </label>
        <input type="text" v-on:keyup="logName">
      </div>

      <div class="group-data-item">
        <label>Age: </label>
        <input type="text" v-on:keyup.enter="logAge">
      </div>

      <div class="group-data-item">
        <label>Job: </label>
        <input type="text" v-on:keyup.alt.enter="logJob">
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'KeyboardEvents',
  data () {
    return {
      msg: 'Keyboard Events'
    }
  },
  methods:{
    logName: function(){
      console.log('you entered name...');
    },

    logAge: function(){
      console.log('you entered age...');
    },

    logJob: function(){
      console.log('you entered job...');
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a, span {
  color: #42b983;
}
.color-text{
  color: #42b983; 
}
.group-data, .group-button{
  margin-bottom: 10px;
}
.group-data-item{
  margin-bottom: 5px;
}
</style>

<template>
  <div>
    <h1>{{msg}}</h1>
    <p>Age: {{age}}</p>
    <div class="group-button">
      <button type="submit" v-on:click="add(1)">Add age</button>
      <button type="submit" v-on:click="subtract(1)">Subtract age</button>
      <button type="submit" v-on:click="add(10)">Add age 10</button>
      <button type="submit" v-on:click="subtract(10)">Subtract age 10</button>
      <button type="submit" v-on:click.once="alert()">Alert</button>
    </div>
    <a v-bind:href="web">Demo1</a>
    <a v-on:click="alert()" v-bind:href="web">Demo2</a>
    <a v-on:click.prevent="alert()" v-bind:href="web">Demo3</a>
  </div>
</template>

<script>
export default {
  name: 'EventModifier',
  data () {
    return {
      msg: 'Event Modifier',
      age: 23,
      x: 0,
      y: 0,
      web: 'https://vuejs.org'
    }
  },
  methods:{
    add: function(age){
      this.age += age;
    },

    subtract: function(age){
      this.age -= age;
    },

    alert: function(){
      alert('This is alert');
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a, span {
  color: #42b983;
}
.color-text{
  color: #42b983; 
}
.group-data, .group-button{
  margin-bottom: 10px;
}
.group-data-item{
  margin-bottom: 5px;
}
</style>

<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <h2>Vue Session</h2>
    <ul>
      <li><router-link to="/home">Home</router-link></li>
      <li><router-link to="/binding">Data Binding</router-link></li>
      <li><router-link to="/datamethod">Data Method</router-link></li>
      <li><router-link to="/event">Event</router-link></li>
      <br>
      <li><router-link to="/event-modifier">Event Modifier</router-link></li>
      <li><router-link to="/hello">Hello World</router-link></li>
      <li><router-link to="/keyboard">Keyboard Events</router-link></li>
      <li><router-link to="/two-way-binding">Two-way Data Binding</router-link></li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'Home',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>

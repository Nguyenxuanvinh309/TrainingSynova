<template>
  <div>
    <h1>{{msg}}</h1>
    <div class="group-data">
      <div class="group-data-item">
        <label>Name: </label>
        <input type="text" v-model="name">
      </div>
      <div class="group-data-item">
        <label>Job: </label>
        <input type="text" v-model="job">
      </div>
      <div class="group-data-item">
        <label>Age: </label>
        <input type="text" v-model="old">
      </div>
    </div>
    <hr>
    <ul class="information-area"><b>Information</b>
      <li>Name: {{name}}</li>
      <li>Job: {{job}}</li>
      <li>Old: {{old}}</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'TwoWayDataBinding',
  data () {
    return {
      msg: 'Two-Way Data Binding',
      name: 'Kai',
      job: 'Dev',
      old: 23
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
.information-area{
  font-size: 32px;
  text-transform: uppercase;
}
.information-area li{
  display: list-item;
  font-size: 20px;
}
a, span {
  color: #42b983;
}
.color-text{
  color: #42b983; 
}
.group-data, .group-button{
  margin-bottom: 10px;
}
.group-data-item{
  margin-bottom: 5px;
}
</style>
